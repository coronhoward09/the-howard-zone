﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gettingStarted
{
    class Program
    {
        static void Main(string[] args)
        {
            double Ex = 0.2;
            double Go = 0.15;
            double Ok = 0.1;
            double tip, total;
            char cont = 'y';
            Console.WriteLine("Tip Calculator");//title
            while (cont == 'y')
            {
                Console.Write("How much is your bill? ");
                double Bill = Convert.ToDouble(Console.ReadLine());//input bill amount 
                Console.Write("How was the service?\nE = Excellent,  G = Good, O = Ok ");//request input for service
                char service = Convert.ToChar(Console.ReadLine());//input for service
                service = char.ToUpper(service);//convert input to uppercase 

                if (service == 'E')
                {
                    tip = (Bill * Ex);
                    total = (Bill * Ex) + Bill;
                    Console.WriteLine("You should tip " + tip.ToString("F"));//stops number 2 pass decimal
                    Console.WriteLine("Your total is " + total.ToString("F"));//stops number 2 pass decimal
                }//end if
                else if (service == 'G')
                {
                    tip = (Bill * Go);
                    total = (Bill * Go) + Bill;
                    Console.WriteLine("You should tip " + tip.ToString("F"));//stops number 2 pass decimal
                    Console.WriteLine("Your total is " + total.ToString("F"));//stops number 2 pass decimal
                }//end if
                else if (service == 'O')
                {
                    tip = (Bill * Ok);
                    total = (Bill * Ok) + Bill;
                    Console.WriteLine("You should tip " + tip.ToString("F"));//stops number 2 pass decimal
                    Console.WriteLine("Your total is " + total.ToString("F"));//stops number 2 pass decimal
                }//end if

                Console.Write("would you like to calculate another tip? y/n ");
                cont = Convert.ToChar(Console.ReadLine());


                Console.ReadLine();

            }//end loop
          
        }
    }
}
  